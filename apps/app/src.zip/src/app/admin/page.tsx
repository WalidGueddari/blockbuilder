import { DashboardPage } from '@/components/modules/v2/admin';
import ProtectedRoute from '@/views/private-route';
import AdminRoute from '@/views/admine-route';

export default function Home() {
  return (
    <div>
      <ProtectedRoute>
        {/* <AdminRoute> */}
          <DashboardPage />
        {/* </AdminRoute> */}
      </ProtectedRoute>
    </div>
  );
}
