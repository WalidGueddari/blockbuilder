// types/network.ts
export interface NetworkDetailsProps {
  networkId: string;
}

export interface ContainerProps {
  networkId: string;
  container: string;
  logs: string[]; // Array of log messages
}

export type InitNetworkPayload = {
  name: string;
  userId: string;
  nodeCount: number;
};

export type InitNetwork = {
  id: string;
  name: string;
  userId: string;
  status: string;
  nodeCount: number;
  createdAt: string;
};

export interface Pagination {
  page: number;
  limit: number;
  pages: number;
  total: number;
  next: number | null;
  prev: number | null;
}

export interface NetworksResponse {
  success: boolean;
  data: InitNetwork[];
  pagination: Pagination;
}
