// components/AdminRoute.tsx
'use client';

import { useUserRole } from '@/hooks/use-user-role';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const AdminRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAdmin, isLoading } = useUserRole();

  // still checking sessionStorage…
  if (isLoading) {
    return null;
  }

  // not an admin → show unauthorized card
  if (!isAdmin) {
    return (
      <Card className="max-w-md mx-auto mt-10">
        <CardHeader>
          <CardTitle>Unauthorized</CardTitle>
        </CardHeader>
        <CardContent>
          You do not have permission to view this page.
        </CardContent>
      </Card>
    );
  }

  // admin → show chatbot + protected content
  return (
    <>
      {children}
    </>
  );
};

export default AdminRoute;
