// src/components/modules/v2/activation/overview.tsx
"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAppDispatch, useAppSelector } from "@/services/hooks";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";
import { CheckCircle, XCircle } from "lucide-react";
import {
  activateUser,
  selectAdminLoading,
} from "@/services/v1/adminSlice";

export default function ActivationPage() {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const isLoading = useAppSelector(selectAdminLoading);

  const [code, setCode] = useState<string[]>(Array(6).fill(""));
  const [userIsActive, setUserIsActive] = useState<boolean>(false);
  const [activationError, setActivationError] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);

  // grab userId once
  useEffect(() => {
    const stored = sessionStorage.getItem("user");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (parsed.id) setUserId(parsed.id);
      } catch {
        console.error("Invalid user in sessionStorage");
      }
    }
  }, []);

  const handleChange = (idx: number, val: string) => {
    if (val && !/^\d+$/.test(val)) return;
    const next = [...code];
    next[idx] = val;
    setCode(next);
    if (val && idx < code.length - 1) {
      document.getElementById(`code-${idx + 1}`)?.focus();
    }
  };

  const handleKeyDown = (
    idx: number,
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (e.key === "Backspace" && !code[idx] && idx > 0) {
      document.getElementById(`code-${idx - 1}`)?.focus();
    }
    if (e.key === "ArrowLeft" && idx > 0) {
      document.getElementById(`code-${idx - 1}`)?.focus();
    }
    if (e.key === "ArrowRight" && idx < code.length - 1) {
      document.getElementById(`code-${idx + 1}`)?.focus();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setActivationError(null);

    const activationCode = code.join("");
    if (activationCode.length !== code.length) {
      return toast({
        title: "Invalid code",
        description: `Enter all ${code.length} digits.`,
        variant: "destructive",
      });
    }
    if (!userId) {
      return toast({
        title: "Missing user ID",
        description: "Unable to activate without your user ID.",
        variant: "destructive",
      });
    }

    try {
      // assume payload: { user: { isActive: true, … }, message: … }
      const payload = await dispatch(
        activateUser({ userId, code: activationCode })
      ).unwrap();

      // locally mark as active
      setUserIsActive(true);

      // persist the updated user object back into sessionStorage
      const stored = sessionStorage.getItem("user");
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          const updated = { ...parsed, ...payload.data };
          sessionStorage.setItem("user", JSON.stringify(updated));
        } catch {}
      }

      toast({
        title: "Account activated!",
        description: "Redirecting shortly…",
      });
      router.push("/");
    } catch (err: any) {
      const msg = err.message || "Activation failed";
      setActivationError(msg);
      toast({
        title: "Activation failed",
        description: msg,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl text-center">
            Activate Your Account
          </CardTitle>
          <CardDescription className="text-center">
            Enter the 6-digit code from your email
          </CardDescription>
        </CardHeader>

        <CardContent>
          {userIsActive ? (
            <div className="flex flex-col items-center justify-center py-6 space-y-4">
              <CheckCircle className="h-16 w-16 text-green-500" />
              <p className="text-lg font-medium text-center">
                Account successfully activated!
              </p>
              <p className="text-sm text-gray-500 text-center">
                Redirecting you home…
              </p>
            </div>
          ) : activationError ? (
            <div className="flex flex-col items-center justify-center py-6 space-y-4">
              <XCircle className="h-16 w-16 text-red-500" />
              <p className="text-lg font-medium text-center">
                Activation failed
              </p>
              <p className="text-sm text-gray-500 text-center">
                {activationError}
              </p>
              <Button
                variant="outline"
                onClick={() => {
                  setActivationError(null);
                  setCode(Array(6).fill(""));
                }}
              >
                Try Again
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="flex justify-center space-x-2 mb-6">
                {code.map((digit, idx) => (
                  <Input
                    key={idx}
                    id={`code-${idx}`}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleChange(idx, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(idx, e)}
                    className="w-12 h-12 text-center text-lg font-semibold"
                    autoFocus={idx === 0}
                    disabled={isLoading}
                  />
                ))}
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={isLoading || code.some((d) => !d)}
              >
                {isLoading ? "Activating…" : "Activate Account"}
              </Button>
            </form>
          )}
        </CardContent>

        <CardFooter className="flex flex-col space-y-2">
          <p className="text-sm text-center text-gray-500">
            Didn’t receive a code? Check your spam folder or…
          </p>
          <Button variant="link" className="p-0 h-auto" disabled={isLoading}>
            Request a new code
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
