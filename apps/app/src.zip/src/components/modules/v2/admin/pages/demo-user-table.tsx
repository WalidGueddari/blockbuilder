"use client"

import { Check, X } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

import type { DemoUser } from "./demo-user-dashboard"

interface DemoUserTableProps {
  users: DemoUser[]
  toggleUserStatus: (userId: string) => void
}

export function DemoUserTable({ users, toggleUserStatus }: DemoUserTableProps) {
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }).format(date)
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Created</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.length === 0 ? (
            <TableRow>
              <TableCell colSpan={5} className="h-24 text-center">
                No demo users found.
              </TableCell>
            </TableRow>
          ) : (
            users.map((user) => (
              <TableRow key={user.id}>
                <TableCell className="font-medium">{user.name}</TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>{formatDate(user.createdAt)}</TableCell>
                <TableCell>
                  <Badge variant={user.isActive ? "outline" : "destructive"} className="gap-1">
                    {user.isActive ? (
                      <>
                        <Check className="h-3 w-3" />
                        <span>Active</span>
                      </>
                    ) : (
                      <>
                        <X className="h-3 w-3" />
                        <span>Inactive</span>
                      </>
                    )}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Switch checked={user.isActive} onCheckedChange={() => toggleUserStatus(user.id)} />
                    <span className="text-xs text-muted-foreground">{user.isActive ? "Deactivate" : "Activate"}</span>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}
