import { DemoUserDashboard } from "@/components/modules/v2/admin/pages/demo-user-dashboard"

export default function DashboardPage() {
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-bold mb-8">Demo User Management</h1>
      <DemoUserDashboard />
    </div>
  )
}
