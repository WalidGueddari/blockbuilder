"use client"

import { useState } from "react"
import { PlusCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

import { CreateDemoUserForm } from "./create-demo-user-form"
import { DemoUserTable } from "./demo-user-table"

// Mock data for demo users
export type DemoUser = {
  id: string
  name: string
  email: string
  isActive: boolean
  createdAt: Date
}

const initialDemoUsers: DemoUser[] = [
  {
    id: "1",
    name: "Demo User 1",
    email: "demo1@example.com",
    isActive: true,
    createdAt: new Date("2023-01-15"),
  },
  {
    id: "2",
    name: "Demo User 2",
    email: "demo2@example.com",
    isActive: false,
    createdAt: new Date("2023-02-20"),
  },
  {
    id: "3",
    name: "Demo User 3",
    email: "demo3@example.com",
    isActive: true,
    createdAt: new Date("2023-03-10"),
  },
]

export function DemoUserDashboard() {
  const [demoUsers, setDemoUsers] = useState<DemoUser[]>(initialDemoUsers)
  const [isCreatingUser, setIsCreatingUser] = useState(false)

  const toggleUserStatus = (userId: string) => {
    setDemoUsers(demoUsers.map((user) => (user.id === userId ? { ...user, isActive: !user.isActive } : user)))
  }

  const createDemoUser = (name: string, email: string) => {
    const newUser: DemoUser = {
      id: `${demoUsers.length + 1}`,
      name,
      email,
      isActive: true,
      createdAt: new Date(),
    }

    setDemoUsers([...demoUsers, newUser])
    setIsCreatingUser(false)
  }

  return (
    <Tabs defaultValue="all" className="w-full">
      <div className="flex items-center justify-between mb-4">
        <TabsList>
          <TabsTrigger value="all">All Users</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="inactive">Inactive</TabsTrigger>
        </TabsList>
        <Button onClick={() => setIsCreatingUser(true)} className="gap-2">
          <PlusCircle className="h-4 w-4" />
          Create Demo User
        </Button>
      </div>

      <TabsContent value="all">
        <Card>
          <CardHeader>
            <CardTitle>All Demo Users</CardTitle>
            <CardDescription>Manage all your demo users from this dashboard.</CardDescription>
          </CardHeader>
          <CardContent>
            <DemoUserTable users={demoUsers} toggleUserStatus={toggleUserStatus} />
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="active">
        <Card>
          <CardHeader>
            <CardTitle>Active Demo Users</CardTitle>
            <CardDescription>View and manage currently active demo users.</CardDescription>
          </CardHeader>
          <CardContent>
            <DemoUserTable users={demoUsers.filter((user) => user.isActive)} toggleUserStatus={toggleUserStatus} />
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="inactive">
        <Card>
          <CardHeader>
            <CardTitle>Inactive Demo Users</CardTitle>
            <CardDescription>View and manage currently inactive demo users.</CardDescription>
          </CardHeader>
          <CardContent>
            <DemoUserTable users={demoUsers.filter((user) => !user.isActive)} toggleUserStatus={toggleUserStatus} />
          </CardContent>
        </Card>
      </TabsContent>

      <Dialog open={isCreatingUser} onOpenChange={setIsCreatingUser}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create New Demo User</DialogTitle>
            <DialogDescription>Add a new user with DEMO role to your system.</DialogDescription>
          </DialogHeader>
          <CreateDemoUserForm onSubmit={createDemoUser} onCancel={() => setIsCreatingUser(false)} />
        </DialogContent>
      </Dialog>
    </Tabs>
  )
}
